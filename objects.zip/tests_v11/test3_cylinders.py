"""
Test 3: CYLINDERS — 4 unique container-specific actions.

A: LID DROP     → 9/12 = 3/4  (drop lids on 9 of 12 cups)
B: SPIN         → 4/12 = 1/3  (spin 4 of 12 cylinders — they change color while spinning)
C: KNOCK OVER   → 6/21 = 2/7  (tip 6 of 21 cylinders sideways)
D: SHRINK       → 5/15 = 1/3  (shrink 5 of 15 cylinders)
"""

import time
import math
from shared_utils import *

try:
    from coppeliasim_zmqremoteapi_client import RemoteAPIClient
except ImportError:
    print("ERROR: pip3 install coppeliasim-zmqremoteapi-client")
    exit(1)

CYL_R = 0.03
CYL_H = 0.1
TABLE_Z = 0.05
CUP_C = [0.6, 0.6, 0.7]
RED = [0.85, 0.1, 0.1]
GOLD = [0.8, 0.65, 0.1]
TEAL = [0.0, 0.55, 0.6]
MAGENTA = [0.85, 0.1, 0.6]
WATER_BLUE = [0.2, 0.5, 0.9]
LABEL_C = [0.0, 0.0, 0.0]


def cyl(sim, name, pos, color, r=None, h=None):
    r = r or CYL_R
    h = h or CYL_H
    handle = sim.createPrimitiveShape(sim.primitiveshape_cylinder, [r*2, r*2, h], 0)
    sim.setObjectAlias(handle, name)
    sim.setObjectPosition(handle, -1, pos)
    sim.setShapeColor(handle, None, sim.colorcomponent_ambient_diffuse, color)
    make_static(sim, handle)
    return handle


def clear(sim, handles):
    for h in handles:
        try: sim.removeObject(h)
        except: pass


def run_test():
    print("\n" + "=" * 60)
    print("  TEST 3: CYLINDERS — 4 UNIQUE ACTIONS")
    print("=" * 60)

    client = RemoteAPIClient()
    sim = client.require('sim')
    sim.stopSimulation()
    time.sleep(1)
    sim.startSimulation()
    time.sleep(0.5)

    all_h = []
    gap = 0.1

    # ===========================================================
    # A: LID DROP — 9/12 = 3/4
    # ===========================================================
    log("ACTION A: LID DROP — 9/12 = 3/4")

    cups = []
    for i in range(12):
        x = (i - 5.5) * gap * 1.0
        c = cyl(sim, f"A_cup{i}", [x, 0, TABLE_Z + CYL_H/2], CUP_C)
        cups.append(c)
        all_h.append(c)
        time.sleep(0.12)

    log(f"12 cups. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Dropping RED lids on 9...")
    for i in range(9):
        cp = sim.getObjectPosition(cups[i], -1)
        target_z = TABLE_Z + CYL_H + 0.008
        lid = cyl(sim, f"A_lid{i}", [cp[0], cp[1], target_z + 0.1],
                   RED, r=CYL_R + 0.005, h=0.015)
        all_h.append(lid)
        for s in range(15):
            t = (s+1)/15
            z = (target_z + 0.1) - 0.1 * (t * t)
            sim.setObjectPosition(lid, -1, [cp[0], cp[1], z])
            time.sleep(0.02)
        time.sleep(0.15)

    lbl = render_equivalence(sim, 9, 12, 3, 4, [0, 0, TABLE_Z + CYL_H + 0.08], scale=0.02, color=LABEL_C)
    all_h += lbl
    log("9 lids / 12 cups → 9/12 = 3/4")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # B: SPIN — 4/12 = 1/3
    # 12 cylinders, 4 spin around their axis (and turn magenta)
    # ===========================================================
    log("ACTION B: SPIN — 4/12 = 1/3")

    cyls_b = []
    for i in range(12):
        x = (i - 5.5) * gap * 1.0
        c = cyl(sim, f"B_cyl{i}", [x, 0, TABLE_Z + CYL_H/2], TEAL)
        cyls_b.append(c)
        all_h.append(c)
        time.sleep(0.12)

    log(f"12 teal cylinders. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Spinning 4 cylinders (turn magenta)...")
    for idx in [0, 3, 6, 9]:
        sim.setShapeColor(cyls_b[idx], None, sim.colorcomponent_ambient_diffuse, MAGENTA)
        pos = sim.getObjectPosition(cyls_b[idx], -1)
        for s in range(30):
            angle = (s / 30) * math.pi * 4  # 2 full rotations
            sim.setObjectOrientation(cyls_b[idx], -1, [0, 0, angle])
            time.sleep(0.02)
        time.sleep(0.15)

    lbl = render_equivalence(sim, 4, 12, 1, 3, [0, 0, TABLE_Z + CYL_H + 0.06], scale=0.02, color=LABEL_C)
    all_h += lbl
    log("4 spinning (magenta) / 12 → 4/12 = 1/3")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # C: KNOCK OVER — 6/21 = 2/7
    # ===========================================================
    log("ACTION C: KNOCK OVER — 6/21 = 2/7")

    cyls = []
    for row in range(2):
        count = 11 if row == 0 else 10
        for i in range(count):
            x = (i - count/2 + 0.5) * gap * 0.9
            y = (row - 0.5) * 0.08
            c = cyl(sim, f"C_cyl{row}_{i}", [x, y, TABLE_Z + CYL_H/2], TEAL)
            cyls.append(c)
            all_h.append(c)
            time.sleep(0.05)

    log(f"21 teal cylinders. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Knocking 6 over (red, tipping sideways)...")
    for idx in [0, 3, 7, 11, 15, 18]:
        pos = sim.getObjectPosition(cyls[idx], -1)
        sim.setShapeColor(cyls[idx], None, sim.colorcomponent_ambient_diffuse, RED)

        for s in range(20):
            t = s / 20
            angle = (math.pi / 2) * t
            new_z = TABLE_Z + CYL_H/2 * math.cos(angle) + CYL_R * math.sin(angle)
            new_y = pos[1] + CYL_H/2 * math.sin(angle) - CYL_R * math.cos(angle) + CYL_R
            sim.setObjectOrientation(cyls[idx], -1, [angle, 0, 0])
            sim.setObjectPosition(cyls[idx], -1, [pos[0], new_y, new_z])
            time.sleep(0.02)
        time.sleep(0.15)

    lbl = render_equivalence(sim, 6, 21, 2, 7, [0, 0, TABLE_Z + CYL_H + 0.06], scale=0.02, color=LABEL_C)
    all_h += lbl
    log("6 knocked / 21 → 6/21 = 2/7")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # D: SHRINK — 5/15 = 1/3
    # ===========================================================
    log("ACTION D: SHRINK — 5/15 = 1/3")

    cyls2 = []
    for i in range(15):
        x = (i - 7) * gap * 0.95
        c = cyl(sim, f"D_cyl{i}", [x, 0, TABLE_Z + CYL_H/2], GOLD)
        cyls2.append(c)
        all_h.append(c)
        time.sleep(0.08)

    log(f"15 gold cylinders. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Shrinking 5 to half size + magenta...")
    for idx in [0, 3, 6, 9, 12]:
        target = cyls2[idx]
        pos = sim.getObjectPosition(target, -1)

        for s in range(12):
            t = (s + 1) / 12
            scale = 1.0 - 0.5 * t
            new_r = CYL_R * scale
            new_h = CYL_H * scale
            new_z = TABLE_Z + new_h / 2

            sim.removeObject(target)
            target = cyl(sim, f"D_shrink_{idx}_{s}",
                          [pos[0], pos[1], new_z], MAGENTA, r=new_r, h=new_h)
            all_h.append(target)
            time.sleep(0.04)
        time.sleep(0.15)

    lbl = render_equivalence(sim, 5, 15, 1, 3, [0, 0, TABLE_Z + CYL_H + 0.06], scale=0.02, color=LABEL_C)
    all_h += lbl
    log("5 shrunk / 15 → 5/15 = 1/3")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    lbl = render_fraction(sim, 1, 3, [0, 0, TABLE_Z + CYL_H + 0.06], scale=0.025, color=LABEL_C)
    all_h += lbl
    log("1 shrunk (magenta) among 3 → 1/3")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("=" * 50)
    log("TEST 3 — CYLINDERS SUMMARY:")
    log("  A: Lid Drop     → 3/4")
    log("  B: Pour/Fill    → 1/5")
    log("  C: Knock Over   → 2/7")
    log("  D: Shrink       → 1/3")
    log("=" * 50)
    time.sleep(PAUSE)

    sim.stopSimulation()
    print("\n  ✅ TEST 3 COMPLETE")


if __name__ == "__main__":
    run_test()
