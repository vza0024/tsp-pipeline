"""
Test 4: BOOKS (Blender) — 4 actions.

A: OPEN BOOK           → 8/16 = 1/2  (open 8 of 16 books)
B: STACK BOOKS         → 5/15 = 1/3  (stack 3 books on top of 5 out of 15)
C: CHANGE COVER COLOR  → 9/15 = 3/5  (9 of 15 blue → red)
D: SLIDE OFF           → 4/14 = 2/7  (4 of 14 slide off)
"""

import time
import math
import os
import subprocess
from shared_utils import *

try:
    from coppeliasim_zmqremoteapi_client import RemoteAPIClient
except ImportError:
    print("ERROR: pip3 install coppeliasim-zmqremoteapi-client")
    exit(1)

TABLE_Z = 0.05
LABEL_C = [0.0, 0.0, 0.0]
OBJ_DIR = "/tmp/book_v9b"

BOOK_W = 0.06
BOOK_D = 0.08
BOOK_H = 0.015
COVER_H = 0.002
PAGES_H = 0.011
SPINE_W = 0.004

COVER_BLUE = [0.15, 0.25, 0.7]
COVER_RED = [0.75, 0.1, 0.1]
COVER_GREEN = [0.1, 0.5, 0.15]
COVER_PURPLE = [0.45, 0.1, 0.55]
COVER_BROWN = [0.5, 0.3, 0.1]
COVER_TEAL = [0.1, 0.45, 0.5]
COVER_ORANGE = [0.85, 0.45, 0.05]
PAGES_COLOR = [0.95, 0.93, 0.88]
GOLD = [0.9, 0.75, 0.15]

ALL_COVERS = [COVER_BLUE, COVER_RED, COVER_GREEN, COVER_PURPLE,
              COVER_BROWN, COVER_TEAL, COVER_ORANGE, [0.6, 0.1, 0.3], [0.3, 0.3, 0.6]]

BLENDER_SCRIPT = """
import bpy, os

d = "OBJ_DIR_PH"
os.makedirs(d, exist_ok=True)

def cl():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete()

def mat(name, r, g, b):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (r, g, b, 1.0)
    return m

def ex(o, f):
    bpy.ops.object.select_all(action='DESELECT')
    o.select_set(True)
    bpy.context.view_layer.objects.active = o
    bpy.ops.wm.obj_export(filepath=os.path.join(d,f), export_selected_objects=True, export_materials=True)

cl()
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0.001))
bot = bpy.context.active_object
bot.scale = (0.03, 0.04, 0.001)
bpy.ops.object.transform_apply(scale=True)
bot.data.materials.append(mat("CoverBot", 0.15, 0.25, 0.7))

bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0.001, 0.0075))
pages = bpy.context.active_object
pages.scale = (0.028, 0.038, 0.0055)
bpy.ops.object.transform_apply(scale=True)
pages.data.materials.append(mat("Pages", 0.95, 0.93, 0.88))

bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0.014))
top = bpy.context.active_object
top.scale = (0.03, 0.04, 0.001)
bpy.ops.object.transform_apply(scale=True)
top.data.materials.append(mat("CoverTop", 0.15, 0.25, 0.7))

bpy.ops.mesh.primitive_cube_add(size=1, location=(-0.03, 0, 0.0075))
spine = bpy.context.active_object
spine.scale = (0.002, 0.04, 0.007)
bpy.ops.object.transform_apply(scale=True)
spine.data.materials.append(mat("Spine", 0.1, 0.15, 0.5))

bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0.0155))
title = bpy.context.active_object
title.scale = (0.02, 0.008, 0.0003)
bpy.ops.object.transform_apply(scale=True)
title.data.materials.append(mat("Title", 0.85, 0.75, 0.3))

for o in [bot, pages, top, spine, title]:
    o.select_set(True)
bpy.context.view_layer.objects.active = bot
bpy.ops.object.join()
bpy.ops.object.shade_flat()
ex(bpy.context.active_object, "book.obj")
print("Book exported!")
""".replace("OBJ_DIR_PH", OBJ_DIR)

use_blender = False


def try_blender():
    global use_blender
    print("  Generating book in Blender...")
    p = "/tmp/book_v9b.py"
    with open(p, "w") as f: f.write(BLENDER_SCRIPT)
    try:
        r = subprocess.run(["blender","--background","--python",p],
                           capture_output=True, text=True, timeout=60)
        if r.returncode == 0 and os.path.exists(os.path.join(OBJ_DIR, "book.obj")):
            print("  ✅ Blender: book.obj (cover + pages + spine + title)")
            use_blender = True
            return
    except: pass
    print("  ⚠️ Using CoppeliaSim primitives")
    use_blender = False


def build_book(sim, name, pos, cover_color=None, z_offset=0):
    if cover_color is None:
        cover_color = COVER_BLUE
    x, y = pos[0], pos[1]
    base_z = TABLE_Z + z_offset
    parts = {}; all_p = []

    bot = sim.createPrimitiveShape(sim.primitiveshape_cuboid, [BOOK_W, BOOK_D, COVER_H], 0)
    sim.setObjectAlias(bot, f"{name}_bot")
    sim.setObjectPosition(bot, -1, [x, y, base_z + COVER_H*0.5])
    sim.setShapeColor(bot, None, sim.colorcomponent_ambient_diffuse, cover_color)
    make_static(sim, bot); parts["bot"] = bot; all_p.append(bot)

    pg = sim.createPrimitiveShape(sim.primitiveshape_cuboid, [BOOK_W-0.004, BOOK_D-0.004, PAGES_H], 0)
    sim.setObjectAlias(pg, f"{name}_pg")
    sim.setObjectPosition(pg, -1, [x, y, base_z + COVER_H + PAGES_H*0.5])
    sim.setShapeColor(pg, None, sim.colorcomponent_ambient_diffuse, PAGES_COLOR)
    make_static(sim, pg); parts["pages"] = pg; all_p.append(pg)

    top = sim.createPrimitiveShape(sim.primitiveshape_cuboid, [BOOK_W, BOOK_D, COVER_H], 0)
    sim.setObjectAlias(top, f"{name}_top")
    top_z = base_z + COVER_H + PAGES_H + COVER_H*0.5
    sim.setObjectPosition(top, -1, [x, y, top_z])
    sim.setShapeColor(top, None, sim.colorcomponent_ambient_diffuse, cover_color)
    make_static(sim, top); parts["top"] = top; all_p.append(top)

    sp = sim.createPrimitiveShape(sim.primitiveshape_cuboid, [SPINE_W, BOOK_D, BOOK_H], 0)
    sim.setObjectAlias(sp, f"{name}_sp")
    sim.setObjectPosition(sp, -1, [x - BOOK_W*0.5 + SPINE_W*0.5, y, base_z + BOOK_H*0.5])
    sim.setShapeColor(sp, None, sim.colorcomponent_ambient_diffuse, [max(0,c-0.1) for c in cover_color])
    make_static(sim, sp); parts["spine"] = sp; all_p.append(sp)

    ts = sim.createPrimitiveShape(sim.primitiveshape_cuboid, [BOOK_W*0.6, BOOK_D*0.15, 0.001], 0)
    sim.setObjectAlias(ts, f"{name}_title")
    sim.setObjectPosition(ts, -1, [x, y, top_z + COVER_H*0.5 + 0.001])
    sim.setShapeColor(ts, None, sim.colorcomponent_ambient_diffuse, [0.85, 0.75, 0.3])
    make_static(sim, ts); parts["title"] = ts; all_p.append(ts)

    parts["_all"] = all_p
    parts["_pos"] = [x, y]
    parts["_color"] = cover_color
    return parts


def open_book(sim, book):
    top = book["top"]; title = book["title"]
    x, y = book["_pos"]
    top_z = sim.getObjectPosition(top, -1)[2]
    spine_x = x - BOOK_W * 0.5

    for step in range(25):
        t = (step + 1) / 25
        angle = -(math.pi * 0.35) * t
        dx = BOOK_W * 0.5
        new_x = spine_x + dx * math.cos(angle)
        new_z = top_z + dx * math.sin(-angle)
        sim.setObjectPosition(top, -1, [new_x, y, new_z])
        sim.setObjectOrientation(top, -1, [0, angle, 0])
        sim.setObjectPosition(title, -1, [new_x, y, new_z + 0.002])
        sim.setObjectOrientation(title, -1, [0, angle, 0])
        time.sleep(0.03)


def slide_off(sim, book, direction_x=1):
    all_p = book["_all"]
    frames = 35
    for step in range(frames):
        t = (step + 1) / frames
        speed = t * t * 0.015 * direction_x  # accelerate
        for p in all_p:
            pos = sim.getObjectPosition(p, -1)
            sim.setObjectPosition(p, -1, [pos[0] + speed, pos[1], pos[2]])
        time.sleep(0.02)
    for p in all_p:
        try: sim.removeObject(p)
        except: pass


def clear(sim, handles):
    for h in handles:
        try: sim.removeObject(h)
        except: pass


def run_test():
    print("\n" + "=" * 60)
    print("  TEST 4: BOOKS (BLENDER) — 4 ACTIONS")
    print("=" * 60)

    try_blender()

    client = RemoteAPIClient()
    sim = client.require('sim')
    sim.stopSimulation()
    time.sleep(1)
    sim.startSimulation()
    time.sleep(0.5)

    all_h = []
    gap = 0.11

    # ===========================================================
    # A: OPEN BOOK — 8/16 = 1/2
    # ===========================================================
    log("ACTION A: OPEN BOOK — 8/16 = 1/2")

    books = []
    for i in range(16):
        x = (i - 7.5) * gap * 0.85
        b = build_book(sim, f"A_{i}", [x, 0], ALL_COVERS[i % len(ALL_COVERS)])
        books.append(b)
        all_h += b["_all"]
        time.sleep(0.1)

    log(f"16 books. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Opening 8 books...")
    for idx in range(8):
        open_book(sim, books[idx])
        time.sleep(0.3)

    lbl = render_equivalence(sim, 8, 16, 1, 2, [0, 0, TABLE_Z + 0.08], scale=0.015, color=LABEL_C)
    all_h += lbl
    log("8 open / 16 → 8/16 = 1/2")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # B: STACK BOOKS — 5/15 = 1/3
    # 15 books in a row, stack 3 extra books on top of 5
    # ===========================================================
    log("ACTION B: STACK BOOKS — 5/15 = 1/3")

    books = []
    for i in range(15):
        x = (i - 7) * gap * 0.85
        b = build_book(sim, f"B_{i}", [x, 0], ALL_COVERS[i % len(ALL_COVERS)])
        books.append(b)
        all_h += b["_all"]
        time.sleep(0.08)

    log(f"15 books in a row. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Stacking 3 books on top of 5 books...")
    for idx in [1, 4, 7, 10, 13]:
        bpos = books[idx]["_pos"]
        bcolor = books[idx]["_color"]
        # Stack 3 books on top
        for layer in range(3):
            z_off = BOOK_H * (layer + 1) + 0.002 * (layer + 1)
            stk = build_book(sim, f"B_stk{idx}_L{layer}", [bpos[0], bpos[1]], bcolor,
                              z_offset=z_off)
            all_h += stk["_all"]
            time.sleep(0.1)
        time.sleep(0.2)

    lbl = render_equivalence(sim, 5, 15, 1, 3, [0, 0, TABLE_Z + 0.1], scale=0.015, color=LABEL_C)
    all_h += lbl
    log("5 stacked (3 high each) / 15 → 5/15 = 1/3")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # C: CHANGE COVER COLOR — 9/15 = 3/5
    # ===========================================================
    log("ACTION C: CHANGE COVER — 9/15 = 3/5")

    books = []
    for i in range(15):
        x = (i - 7) * gap * 0.85
        b = build_book(sim, f"C_{i}", [x, 0], COVER_BLUE)
        books.append(b)
        all_h += b["_all"]
        time.sleep(0.08)

    log(f"15 blue books. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Changing 9 covers to RED...")
    for idx in range(9):
        for pn in ["top", "bot", "spine"]:
            sim.setShapeColor(books[idx][pn], None,
                               sim.colorcomponent_ambient_diffuse, COVER_RED)
        time.sleep(0.3)

    lbl = render_equivalence(sim, 9, 15, 3, 5, [0, 0, TABLE_Z + 0.08], scale=0.015, color=LABEL_C)
    all_h += lbl
    log("9 red / 15 → 9/15 = 3/5")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # D: SLIDE OFF — 4/14 = 2/7
    # ===========================================================
    log("ACTION D: SLIDE OFF — 4/14 = 2/7")

    books = []
    for i in range(14):
        x = (i - 6.5) * gap * 0.85
        b = build_book(sim, f"D_{i}", [x, 0], ALL_COVERS[i % len(ALL_COVERS)])
        books.append(b)
        all_h += b["_all"]
        time.sleep(0.08)

    log(f"14 books. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Sliding 4 books off to the right...")
    for idx in [2, 5, 9, 12]:
        slide_off(sim, books[idx], direction_x=1)
        time.sleep(0.3)

    lbl = render_equivalence(sim, 4, 14, 2, 7, [0, 0, TABLE_Z + 0.08], scale=0.015, color=LABEL_C)
    all_h += lbl
    log("4 slid off / 14 → 4/14 = 2/7")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("=" * 50)
    log("TEST 4 — BOOKS:")
    log("  A: Open Book    → 1/2")
    log("  B: Stack Books  → 1/3")
    log("  C: Change Cover → 3/5")
    log("  D: Slide Off    → 2/7")
    log("=" * 50)
    time.sleep(PAUSE)

    sim.stopSimulation()
    print("\n  ✅ TEST 4 COMPLETE")


if __name__ == "__main__":
    run_test()
