"""
Test 2: FLAT TILES — 4 unique tile-specific actions.

A: FILL           → 8/16 = 1/2  (fill 8 of 16 tiles)
B: STAMP PATTERN  → 9/15 = 3/5  (stamp X on 9 of 15)
C: ROTATE         → 6/21 = 2/7  (rotate 6 of 21 tiles 45°)
D: GROW           → 8/18 = 4/9  (8 of 18 tiles grow bigger)
"""

import time
import math
from shared_utils import *

try:
    from coppeliasim_zmqremoteapi_client import RemoteAPIClient
except ImportError:
    print("ERROR: pip3 install coppeliasim-zmqremoteapi-client")
    exit(1)

TILE = 0.08
GAP = 0.005
TILE_H = 0.01
TABLE_Z = 0.05
LABEL_C = [0.0, 0.0, 0.0]

CREAM = [0.95, 0.92, 0.82]
BLUE = [0.15, 0.4, 0.9]
ORANGE = [0.95, 0.5, 0.0]
CORAL = [0.95, 0.55, 0.55]
BRIGHT_TEAL = [0.0, 0.85, 0.75]
LIGHT_GREEN = [0.7, 0.95, 0.7]
PURPLE = [0.55, 0.2, 0.8]


def tile(sim, name, pos, color):
    h = sim.createPrimitiveShape(sim.primitiveshape_cuboid, [TILE, TILE, TILE_H], 0)
    sim.setObjectAlias(h, name)
    sim.setObjectPosition(h, -1, pos)
    sim.setShapeColor(h, None, sim.colorcomponent_ambient_diffuse, color)
    make_static(sim, h)
    return h


def clear(sim, handles):
    for h in handles:
        try: sim.removeObject(h)
        except: pass


def run_test():
    print("\n" + "=" * 60)
    print("  TEST 2: FLAT TILES — 4 UNIQUE ACTIONS")
    print("=" * 60)

    client = RemoteAPIClient()
    sim = client.require('sim')
    sim.stopSimulation()
    time.sleep(1)
    sim.startSimulation()
    time.sleep(0.5)

    all_h = []
    step = TILE + GAP

    # ===========================================================
    # A: FILL — 8/16 = 1/2 (BLUE on CREAM)
    # ===========================================================
    log("ACTION A: FILL — 8/16 = 1/2")

    tiles = []
    for row in range(2):
        for col in range(8):
            x = (col - 3.5) * step
            y = (row - 0.5) * step
            t = tile(sim, f"A_{row}_{col}", [x, y, TABLE_Z], CREAM)
            tiles.append(t)
            all_h.append(t)
            time.sleep(0.06)

    log(f"16 cream tiles. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    for i in range(8):
        sim.setShapeColor(tiles[i], None, sim.colorcomponent_ambient_diffuse, BLUE)
        time.sleep(0.2)

    lbl = render_equivalence(sim, 8, 16, 1, 2, [0, 0, TABLE_Z + 0.08], scale=0.018, color=LABEL_C)
    all_h += lbl
    log("8 blue / 16 → 8/16 = 1/2")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # B: STAMP PATTERN — 9/15 = 3/5
    # ===========================================================
    log("ACTION B: STAMP — 9/15 = 3/5")

    tiles = []
    for i in range(15):
        x = (i - 7) * step * 1.1
        t = tile(sim, f"B_{i}", [x, 0, TABLE_Z], CREAM)
        tiles.append(t)
        all_h.append(t)
        time.sleep(0.06)

    log(f"15 cream tiles. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    for idx in range(9):
        tp = sim.getObjectPosition(tiles[idx], -1)
        for angle in [0.785, -0.785]:
            bar = sim.createPrimitiveShape(sim.primitiveshape_cuboid,
                [TILE * 0.5, 0.01, 0.01], 0)
            sim.setObjectPosition(bar, -1, [tp[0], tp[1], TABLE_Z + TILE_H/2 + 0.007])
            sim.setObjectOrientation(bar, -1, [0, 0, angle])
            sim.setShapeColor(bar, None, sim.colorcomponent_ambient_diffuse, ORANGE)
            make_static(sim, bar)
            all_h.append(bar)
        time.sleep(0.15)

    lbl = render_equivalence(sim, 9, 15, 3, 5, [0, 0, TABLE_Z + 0.08], scale=0.018, color=LABEL_C)
    all_h += lbl
    log("9 stamped / 15 → 9/15 = 3/5")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # C: ROTATE — 6/21 = 2/7
    # ===========================================================
    log("ACTION C: ROTATE — 6/21 = 2/7")

    tiles = []
    for i in range(21):
        x = (i - 10) * step * 0.85
        t = tile(sim, f"C_{i}", [x, 0, TABLE_Z], CORAL)
        tiles.append(t)
        all_h.append(t)
        time.sleep(0.05)

    log(f"21 coral tiles. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Rotating 6 tiles 45°...")
    for idx in [0, 3, 7, 11, 15, 19]:
        sim.setShapeColor(tiles[idx], None, sim.colorcomponent_ambient_diffuse, BRIGHT_TEAL)
        pos = sim.getObjectPosition(tiles[idx], -1)
        for s in range(15):
            t_frac = (s + 1) / 15
            angle = (math.pi / 4) * t_frac
            sim.setObjectOrientation(tiles[idx], -1, [0, 0, angle])
            lift = 0.012 * math.sin(t_frac * math.pi)
            sim.setObjectPosition(tiles[idx], -1, [pos[0], pos[1], pos[2] + lift])
            time.sleep(0.02)
        time.sleep(0.1)

    lbl = render_equivalence(sim, 6, 21, 2, 7, [0, 0, TABLE_Z + 0.08], scale=0.018, color=LABEL_C)
    all_h += lbl
    log("6 teal diamonds / 21 → 6/21 = 2/7")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # D: GROW — 8/18 = 4/9
    # 18 tiles in 2 rows, 8 grow bigger
    # ===========================================================
    log("ACTION D: GROW — 8/18 = 4/9")

    tiles = []
    positions = []
    for row in range(2):
        for col in range(9):
            x = (col - 4) * step * 1.1
            y = (row - 0.5) * step * 1.3
            t = tile(sim, f"D_{row}{col}", [x, y, TABLE_Z], LIGHT_GREEN)
            tiles.append(t)
            positions.append([x, y])
            all_h.append(t)
            time.sleep(0.05)

    log(f"18 green tiles. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Growing 8 tiles bigger + PURPLE...")
    grow_indices = [0, 2, 4, 6, 9, 11, 13, 15]
    for idx in grow_indices:
        px, py = positions[idx]
        orig_tile = tiles[idx]
        for s in range(10):
            t_frac = (s + 1) / 10
            new_size = TILE * (1.0 + 0.5 * t_frac)
            new_h = TILE_H * (1.0 + 0.3 * t_frac)
            sim.removeObject(orig_tile)
            orig_tile = sim.createPrimitiveShape(sim.primitiveshape_cuboid,
                [new_size, new_size, new_h], 0)
            sim.setObjectAlias(orig_tile, f"D_grow_{idx}_{s}")
            sim.setObjectPosition(orig_tile, -1, [px, py, TABLE_Z])
            sim.setShapeColor(orig_tile, None, sim.colorcomponent_ambient_diffuse, PURPLE)
            make_static(sim, orig_tile)
            time.sleep(0.03)
        tiles[idx] = orig_tile
        all_h.append(orig_tile)
        time.sleep(0.1)

    lbl = render_equivalence(sim, 8, 18, 4, 9, [0.2, 0, TABLE_Z + 0.08], scale=0.018, color=LABEL_C)
    all_h += lbl
    log("8 purple grew / 18 → 8/18 = 4/9")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("=" * 50)
    log("TEST 2 — TILES SUMMARY:")
    log("  A: Fill    → 8/16 = 1/2")
    log("  B: Stamp   → 9/15 = 3/5")
    log("  C: Rotate  → 6/21 = 2/7")
    log("  D: Grow    → 8/18 = 4/9")
    log("=" * 50)
    time.sleep(PAUSE)

    sim.stopSimulation()
    print("\n  ✅ TEST 2 COMPLETE")


if __name__ == "__main__":
    run_test()
