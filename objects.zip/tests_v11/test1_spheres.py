"""
Test 1: SPHERES — 4 actions, each unique.

A: BOUNCE       → 1/2  (3 of 6 spheres bounce up and stay elevated)
B: GROUPING     → 1/3  (ORANGE group vs CYAN/LIME groups)
C: SPLIT        → 2/5  (PURPLE halves vs WHITE whole)
D: PUSH APART   → 1/7  (BRIGHT YELLOW pushed vs DARK NAVY group)
"""

import time
import math
from shared_utils import *

try:
    from coppeliasim_zmqremoteapi_client import RemoteAPIClient
except ImportError:
    print("ERROR: pip3 install coppeliasim-zmqremoteapi-client")
    exit(1)

SPHERE_R = 0.035
TABLE_Z = 0.05
LABEL_C = [0.0, 0.0, 0.0]

# Completely different color pairs per action
A_SEL = [0.85, 0.1, 0.1]     # RED
A_REST = [0.1, 0.7, 0.2]     # GREEN

B_SEL = [0.95, 0.55, 0.0]    # ORANGE
B_REST1 = [0.0, 0.75, 0.75]  # CYAN (group 2)
B_REST2 = [0.3, 0.85, 0.4]   # LIME GREEN (group 3) — different from group 2!

C_SEL = [0.6, 0.15, 0.75]    # PURPLE
C_REST = [0.92, 0.92, 0.92]  # WHITE

D_SEL = [1.0, 0.9, 0.0]      # BRIGHT YELLOW
D_REST = [0.1, 0.1, 0.35]    # DARK NAVY


def sphere(sim, name, pos, color):
    h = sim.createPrimitiveShape(sim.primitiveshape_spheroid,
        [SPHERE_R*2, SPHERE_R*2, SPHERE_R*2], 0)
    sim.setObjectAlias(h, name)
    sim.setObjectPosition(h, -1, pos)
    sim.setShapeColor(h, None, sim.colorcomponent_ambient_diffuse, color)
    make_static(sim, h)
    return h


def half_sphere(sim, name, pos, color):
    h = sim.createPrimitiveShape(sim.primitiveshape_spheroid,
        [SPHERE_R*2, SPHERE_R*2, SPHERE_R], 0)
    sim.setObjectAlias(h, name)
    sim.setObjectPosition(h, -1, pos)
    sim.setShapeColor(h, None, sim.colorcomponent_ambient_diffuse, color)
    make_static(sim, h)
    return h


def clear(sim, handles):
    for h in handles:
        try: sim.removeObject(h)
        except: pass


def run_test():
    print("\n" + "=" * 60)
    print("  TEST 1: SPHERES — 4 ACTIONS, DISTINCT COLORS")
    print("=" * 60)

    client = RemoteAPIClient()
    sim = client.require('sim')
    sim.stopSimulation()
    time.sleep(1)
    sim.startSimulation()
    time.sleep(0.5)

    all_h = []

    # ===========================================================
    # A: BOUNCE — 7/14 = 1/2
    # 14 spheres, 7 bounce up and stay elevated (stay GREEN)
    # ===========================================================
    log("ACTION A: BOUNCE — 7/14 = 1/2")

    spheres = []
    for i in range(14):
        x = (i - 6.5) * 0.09
        s = sphere(sim, f"A_{i}", [x, 0, TABLE_Z + SPHERE_R], A_REST)
        spheres.append(s)
        all_h.append(s)
        time.sleep(0.15)

    log(f"14 green spheres. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Bouncing 7 spheres up (stay green)...")
    bounce_height = 0.08
    for i in range(7):
        pos = sim.getObjectPosition(spheres[i], -1)
        for step in range(25):
            t = step / 25
            if t < 0.4:
                h = bounce_height * (t / 0.4)
            elif t < 0.6:
                h = bounce_height * (1.0 + 0.2 * math.sin((t - 0.4) / 0.2 * math.pi))
            else:
                h = bounce_height * (1.0 + 0.1 * math.sin((t - 0.6) / 0.4 * math.pi * 2) * (1 - t))
            sim.setObjectPosition(spheres[i], -1, [pos[0], pos[1], pos[2] + h])
            time.sleep(0.015)
        sim.setObjectPosition(spheres[i], -1, [pos[0], pos[1], pos[2] + bounce_height])
        time.sleep(0.15)

    lbl = render_equivalence(sim, 7, 14, 1, 2, [0, 0, TABLE_Z + 0.22], scale=0.02, color=LABEL_C)
    all_h += lbl
    log("7 up / 14 → 7/14 = 1/2")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # B: GROUPING — 1/3 (ORANGE vs CYAN vs LIME)
    # Each group has a DIFFERENT color
    # ===========================================================
    # B: GROUPING — 5/15 = 1/3 (ORANGE group vs CYAN vs LIME groups)
    # 3 groups of 5 spheres each = 15 total
    # ===========================================================
    log("ACTION B: GROUPING — 5/15 = 1/3")

    group_colors = [B_SEL, B_REST1, B_REST2]
    box_colors = [[1.0, 0.8, 0.6], [0.6, 0.95, 0.95], [0.7, 1.0, 0.7]]

    for g in range(3):
        gx = (g - 1) * 0.4
        for j in range(5):
            jx = gx + (j - 2) * 0.085
            s = sphere(sim, f"B_g{g}s{j}", [jx, 0, TABLE_Z + SPHERE_R], group_colors[g])
            all_h.append(s)
            time.sleep(0.1)

    for g in range(3):
        gx = (g - 1) * 0.4
        box = sim.createPrimitiveShape(sim.primitiveshape_cuboid, [0.38, 0.09, 0.004], 0)
        sim.setObjectPosition(box, -1, [gx, 0, TABLE_Z])
        sim.setShapeColor(box, None, sim.colorcomponent_ambient_diffuse, box_colors[g])
        make_static(sim, box)
        all_h.append(box)
        time.sleep(0.2)

    lbl = render_equivalence(sim, 5, 15, 1, 3, [0, 0, TABLE_Z + 0.12], scale=0.02, color=LABEL_C)
    all_h += lbl
    log("[🟠×5] [🩵×5] [🟩×5] → 5/15 = 1/3")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # C: SPLIT — 6/15 = 2/5 (PURPLE halves vs WHITE whole)
    # 15 spheres, split 6 of them
    # ===========================================================
    log("ACTION C: SPLIT — 6/15 = 2/5 (PURPLE vs WHITE)")

    spheres_c = []
    for i in range(15):
        x = (i - 7) * 0.09
        s = sphere(sim, f"C_{i}", [x, 0, TABLE_Z + SPHERE_R], C_REST)
        spheres_c.append(s)
        all_h.append(s)
        time.sleep(0.1)

    log(f"15 white spheres. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    for idx in range(6):
        pos = sim.getObjectPosition(spheres_c[idx], -1)
        sim.removeObject(spheres_c[idx])
        h1 = half_sphere(sim, f"C_h{idx}_t",
                          [pos[0], pos[1] - 0.02, pos[2] + SPHERE_R * 0.3], C_SEL)
        h2 = half_sphere(sim, f"C_h{idx}_b",
                          [pos[0], pos[1] + 0.02, pos[2] - SPHERE_R * 0.3], C_SEL)
        all_h += [h1, h2]
        for step in range(10):
            t = step / 10
            offset = 0.02 * t
            sim.setObjectPosition(h1, -1, [pos[0], pos[1] - 0.02 - offset, pos[2] + SPHERE_R * 0.3])
            sim.setObjectPosition(h2, -1, [pos[0], pos[1] + 0.02 + offset, pos[2] - SPHERE_R * 0.3])
            time.sleep(0.03)
        time.sleep(0.2)

    lbl = render_equivalence(sim, 6, 15, 2, 5, [0, 0, TABLE_Z + 0.12], scale=0.02, color=LABEL_C)
    all_h += lbl
    log("6 split / 15 → 6/15 = 2/5")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)
    clear(sim, all_h); all_h = []; time.sleep(1)

    # ===========================================================
    # D: PUSH APART — 3/21 = 1/7 (YELLOW pushed vs NAVY group)
    # 21 spheres in 2 rows, push 3 out
    # ===========================================================
    log("ACTION D: PUSH APART — 3/21 = 1/7")

    spheres_d = []
    for row in range(2):
        count = 11 if row == 0 else 10
        for i in range(count):
            x = (i - count/2 + 0.5) * 0.09
            y = (row - 0.5) * 0.08
            s = sphere(sim, f"D_{row}_{i}", [x, y, TABLE_Z + SPHERE_R], D_REST)
            spheres_d.append(s)
            all_h.append(s)
            time.sleep(0.05)

    log(f"21 navy spheres. Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("Pushing 3 apart...")
    for i in range(3):
        target = spheres_d[i]
        sim.setShapeColor(target, None, sim.colorcomponent_ambient_diffuse, D_SEL)
        pos = sim.getObjectPosition(target, -1)
        for step in range(25):
            t = step / 25
            sim.setObjectPosition(target, -1, [pos[0], pos[1] - 0.15 * t, pos[2]])
            time.sleep(0.02)
        time.sleep(0.15)

    lbl = render_equivalence(sim, 3, 21, 1, 7, [0, 0, TABLE_Z + 0.15], scale=0.02, color=LABEL_C)
    all_h += lbl
    log("3 yellow pushed from 21 navy → 3/21 = 1/7")
    log(f"Waiting {PAUSE}s...")
    time.sleep(PAUSE)

    log("=" * 50)
    log("TEST 1 — SPHERES SUMMARY:")
    log("  A: Bounce  (green)             → 7/14 = 1/2")
    log("  B: Grouping (orange/cyan/lime) → 5/15 = 1/3")
    log("  C: Split   (purple/white)      → 6/15 = 2/5")
    log("  D: Push    (yellow/navy)       → 3/21 = 1/7")
    log("=" * 50)
    time.sleep(PAUSE)

    sim.stopSimulation()
    print("\n  ✅ TEST 1 COMPLETE")


if __name__ == "__main__":
    run_test()
