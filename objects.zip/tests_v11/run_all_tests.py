"""
MASTER TEST RUNNER v10 — Equivalent Fractions (BIG NUMBERS)
4 Objects × 4 UNIQUE Actions = 16 Demonstrations

python3 run_all_tests.py           # all
python3 run_all_tests.py --test N  # single (1-4)
"""
import sys, time, traceback
from test1_spheres import run_test as test_1
from test2_tiles import run_test as test_2
from test3_cylinders import run_test as test_3
from test4_books import run_test as test_4

TESTS = {
    1: {"name": "Spheres", "source": "CoppeliaSim",
        "actions": {"Bounce":"7/14=1/2", "Grouping":"5/15=1/3", "Split":"6/15=2/5", "Push Apart":"3/21=1/7"},
        "runner": test_1},
    2: {"name": "Tiles", "source": "CoppeliaSim",
        "actions": {"Fill":"8/16=1/2", "Stamp":"9/15=3/5", "Rotate":"6/21=2/7", "Grow":"8/18=4/9"},
        "runner": test_2},
    3: {"name": "Cylinders", "source": "CoppeliaSim",
        "actions": {"Lid Drop":"9/12=3/4", "Spin":"4/12=1/3", "Knock Over":"6/21=2/7", "Shrink":"5/15=1/3"},
        "runner": test_3},
    4: {"name": "Books", "source": "Blender",
        "actions": {"Open Book":"8/16=1/2", "Stack Books":"5/15=1/3", "Change Cover":"9/15=3/5", "Slide Off":"4/14=2/7"},
        "runner": test_4},
}

def run_all(f=None):
    print("""
╔════════════════════════════════════════════════════════════════╗
║  EQUIVALENT FRACTIONS v10 — BIG NUMBERS                       ║
║  Timer: 4s · 14-21 objects per action                         ║
╚════════════════════════════════════════════════════════════════╝""")
    tests = {f: TESTS[f]} if f else TESTS
    for n,i in tests.items():
        print(f"\n  Test {n}: {i['name']} ({i['source']})")
        for a,fr in i['actions'].items(): print(f"         {a:<20} → {fr}")

    results = {}
    for n,i in tests.items():
        print(f"\n{'#'*60}\n# TEST {n}: {i['name'].upper()}\n{'#'*60}")
        try:
            i["runner"](); results[n]="✅"
        except ConnectionRefusedError:
            print("\n  ❌ CoppeliaSim not running!"); results[n]="🔌"
        except Exception as e:
            print(f"\n  ❌ {e}"); traceback.print_exc(); results[n]="💥"
        if n!=max(tests.keys()): print("\n  ⏳ 5s..."); time.sleep(5)

    print(f"\n{'='*60}\n  RESULTS:")
    for n in sorted(results): print(f"  {results[n]} {TESTS[n]['name']}: {list(TESTS[n]['actions'].values())}")
    print("="*60)

if __name__=="__main__":
    f=None
    if "--test" in sys.argv:
        i=sys.argv.index("--test")
        if i+1<len(sys.argv): f=int(sys.argv[i+1])
    run_all(f)
